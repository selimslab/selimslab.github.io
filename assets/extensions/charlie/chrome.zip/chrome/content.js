(function() {
    console.log("Charlie is here");

})();