(function() {
  // navigate to selimslab.github.io
    window.location.href = 'https://selimslab.github.io';
})();